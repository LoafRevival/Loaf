// Pointing straight to your running Open OSCAR Server API port
const BACKEND_URL = "http://127.0.0.1:8080";

const authToggle = document.getElementById('auth-toggle');
const toggleText = document.getElementById('toggle-text');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');

const errorMsg = document.getElementById('error-msg');
const successMsg = document.getElementById('success-msg');

const authContainer = document.getElementById('auth-container');
const dashboardContainer = document.getElementById('dashboard-container');
const displayUsername = document.getElementById('display-username');
const btnLogout = document.getElementById('btn-logout');

let isRegisterMode = false;

// SWITCH BETWEEN LOGIN AND REGISTRATION MODES
authToggle.addEventListener('click', (e) => {
    e.preventDefault();
    isRegisterMode = !isRegisterMode;
    errorMsg.classList.add('d-none');
    successMsg.classList.add('d-none');

    if (isRegisterMode) {
        loginForm.classList.add('d-none');
        registerForm.classList.remove('d-none');
        toggleText.innerHTML = `Already registered? <a href="#" id="auth-toggle">Back to Sign On</a>`;
    } else {
        registerForm.classList.add('d-none');
        loginForm.classList.remove('d-none');
        toggleText.innerHTML = `New Baker? <a href="#" id="auth-toggle">Create an Account ✨</a>`;
    }
    
    document.getElementById('auth-toggle').addEventListener('click', arguments.callee);
});

// SUBMIT REGISTRATION TO OPEN OSCAR SERVER ENDPOINT
registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorMsg.classList.add('d-none');
    successMsg.classList.add('d-none');

    const username = document.getElementById('reg-user').value;
    const password = document.getElementById('reg-pass').value;

    try {
        const res = await fetch(`${BACKEND_URL}/api/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();

        if (!res.ok) throw new Error(data.error || "Server engine rejected user migration profile.");

        successMsg.textContent = "Screen name claimed successfully! Switch to Sign On.";
        successMsg.classList.remove('d-none');
        registerForm.reset();
    } catch (err) {
        errorMsg.textContent = err.message;
        errorMsg.classList.remove('d-none');
    }
});

// SUBMIT LOGIN HANDSHAKE
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorMsg.classList.add('d-none');
    successMsg.classList.add('d-none');

    const username = document.getElementById('login-user').value;
    const password = document.getElementById('login-pass').value;

    try {
        const res = await fetch(`${BACKEND_URL}/api/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();

        if (!res.ok) throw new Error(data.error || "Handshake token rejected.");

        // SWITCH VIEW TO CORE SECURE DASHBOARD
        displayUsername.textContent = username;
        authContainer.classList.add('d-none');
        dashboardContainer.classList.remove('d-none');
        document.body.style.alignItems = "flex-start";
    } catch (err) {
        errorMsg.textContent = err.message;
        errorMsg.classList.remove('d-none');
    }
});

// DISCONNECT & RETURN TO ENTRANCE
btnLogout.addEventListener('click', () => {
    loginForm.reset();
    dashboardContainer.classList.add('d-none');
    authContainer.classList.remove('d-none');
    document.body.style.alignItems = "center";
});
